Lilac Scents README
